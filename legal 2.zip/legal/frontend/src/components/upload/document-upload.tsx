"use client";

import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { motion, AnimatePresence } from "framer-motion";
import { FileText, Upload, AlertCircle, Scan } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { parseDocument } from "@/lib/api";
import { useAppStore } from "@/store/app-store";
import { t } from "@/lib/i18n";
import type { ParseResult } from "@/types/legal";
import { AIThinking } from "@/components/ui/ai-thinking";

const ACCEPT = {
  "application/pdf": [".pdf"],
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
  "text/plain": [".txt"],
};

interface DocumentUploadProps {
  onParsed?: (result: ParseResult) => void;
}

export function DocumentUpload({ onParsed }: DocumentUploadProps) {
  const { locale, setCurrentParse } = useAppStore();
  const [progress, setProgress] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [forceOcr, setForceOcr] = useState(false);
  const [preview, setPreview] = useState<ParseResult | null>(null);

  const handleFile = async (file: File) => {
    setError(null);
    setLoading(true);
    setProgress(10);
    const interval = setInterval(() => setProgress((p) => Math.min(p + 8, 90)), 200);
    try {
      const result = await parseDocument(file, forceOcr);
      setPreview(result);
      setCurrentParse(result);
      onParsed?.(result);
      setProgress(100);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Upload failed");
    } finally {
      clearInterval(interval);
      setLoading(false);
    }
  };

  const onDrop = useCallback(
    (files: File[]) => {
      if (files[0]) handleFile(files[0]);
    },
    [forceOcr]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: ACCEPT,
    maxFiles: 1,
    maxSize: 25 * 1024 * 1024,
    disabled: loading,
  });

  return (
    <div className="space-y-4">
      <div
        {...getRootProps()}
        className={`glass rounded-2xl border-2 border-dashed p-10 text-center cursor-pointer transition-all ${
          isDragActive ? "border-[#00E5FF] bg-[#00E5FF]/5" : "border-white/10 hover:border-[#7C3AED]/50"
        }`}
      >
        <input {...getInputProps()} />
        <motion.div animate={{ scale: isDragActive ? 1.05 : 1 }}>
          <Upload className="mx-auto h-12 w-12 text-[#7C3AED] mb-4" />
          <p className="text-lg font-medium">{t("upload.drag", locale)}</p>
          <p className="text-sm text-zinc-500 mt-1">{t("upload.or", locale)}</p>
          <p className="text-xs text-zinc-600 mt-3">{t("upload.types", locale)}</p>
        </motion.div>
      </div>

      <div className="flex items-center gap-3 glass rounded-lg px-4 py-3">
        <Scan className="h-4 w-4 text-[#00E5FF]" />
        <Label htmlFor="ocr" className="flex-1 text-sm">
          Enable OCR for scanned PDFs
        </Label>
        <Switch id="ocr" checked={forceOcr} onCheckedChange={setForceOcr} />
      </div>

      <AnimatePresence>
        {loading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <Progress value={progress} className="h-2" />
            <AIThinking label="Extracting document text..." />
          </motion.div>
        )}
      </AnimatePresence>

      {error && (
        <div className="flex items-center gap-2 text-red-400 text-sm glass rounded-lg p-3">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
        </div>
      )}

      {preview && !loading && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-xl p-4"
        >
          <div className="flex items-start gap-3">
            <FileText className="h-8 w-8 text-[#6366F1] shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate">{preview.filename}</p>
              <p className="text-xs text-zinc-500 mt-1">
                {preview.word_count?.toLocaleString()} words · {preview.method} ·{" "}
                {preview.chunk_count ?? 0} chunks
              </p>
              <p className="text-sm text-zinc-400 mt-2 line-clamp-3">{preview.text.slice(0, 300)}...</p>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
