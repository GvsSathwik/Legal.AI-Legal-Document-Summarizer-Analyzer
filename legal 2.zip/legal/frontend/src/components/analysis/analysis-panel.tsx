"use client";

import { motion } from "framer-motion";
import { Calendar, Users, Shield, Lightbulb, FileWarning } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RiskMeter } from "@/components/analysis/risk-meter";
import type { LegalAnalysis, ClauseItem } from "@/types/legal";
import { useAppStore } from "@/store/app-store";
import { t } from "@/lib/i18n";

const clauseLabels: Record<string, string> = {
  termination: "Termination",
  confidentiality: "Confidentiality",
  payment: "Payment",
  liability: "Liability",
  dispute_resolution: "Dispute Resolution",
  governing_law: "Governing Law",
};

function ClauseCard({ item }: { item: ClauseItem }) {
  const colors = { low: "bg-emerald-500/20 text-emerald-400", medium: "bg-amber-500/20 text-amber-400", high: "bg-red-500/20 text-red-400" };
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass rounded-xl p-4 border border-white/5"
    >
      <div className="flex items-start justify-between gap-2">
        <h4 className="font-medium text-sm">{item.title}</h4>
        <Badge className={colors[item.risk]} variant="secondary">{item.risk}</Badge>
      </div>
      <p className="text-xs text-zinc-400 mt-2 line-clamp-4">{item.excerpt}</p>
    </motion.div>
  );
}

export function AnalysisPanel({ analysis }: { analysis: LegalAnalysis }) {
  const { locale } = useAppStore();
  const summary = analysis.executive_summary;
  const risk = analysis.risk_analysis;

  return (
    <Tabs defaultValue="summary" className="w-full">
      <TabsList className="glass w-full flex flex-wrap h-auto gap-1 p-1">
        <TabsTrigger value="summary">{t("analysis.summary", locale)}</TabsTrigger>
        <TabsTrigger value="clauses">{t("analysis.clauses", locale)}</TabsTrigger>
        <TabsTrigger value="risk">{t("analysis.risk", locale)}</TabsTrigger>
        <TabsTrigger value="obligations">{t("analysis.obligations", locale)}</TabsTrigger>
        <TabsTrigger value="insights">{t("analysis.insights", locale)}</TabsTrigger>
        <TabsTrigger value="recommendations">{t("analysis.recommendations", locale)}</TabsTrigger>
      </TabsList>

      <TabsContent value="summary" className="mt-4 space-y-4">
        <motion.div className="glass rounded-2xl p-6" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <p className="text-zinc-300 leading-relaxed">{summary?.plain_english}</p>
          <p className="mt-4 text-sm text-zinc-500"><strong className="text-zinc-300">Purpose:</strong> {summary?.purpose}</p>
          <div className="mt-4">
            <h4 className="text-sm font-medium mb-2">Main Obligations</h4>
            <ul className="space-y-1">
              {(summary?.main_obligations || []).map((o, i) => (
                <li key={i} className="text-sm text-zinc-400 flex gap-2"><span className="text-[#7C3AED]">•</span>{o}</li>
              ))}
            </ul>
          </div>
          <div className="grid sm:grid-cols-2 gap-4 mt-6">
            <div className="glass rounded-xl p-4">
              <div className="flex items-center gap-2 text-[#00E5FF] mb-2"><Users className="h-4 w-4" /><span className="text-sm font-medium">Parties</span></div>
              {(summary?.parties || []).map((p, i) => (
                <p key={i} className="text-sm text-zinc-400">{p.name} — <span className="text-zinc-500">{p.role}</span></p>
              ))}
            </div>
            <div className="glass rounded-xl p-4">
              <div className="flex items-center gap-2 text-[#00E5FF] mb-2"><Calendar className="h-4 w-4" /><span className="text-sm font-medium">Important Dates</span></div>
              {(summary?.important_dates || []).map((d, i) => (
                <p key={i} className="text-sm text-zinc-400">{d.label}: {d.date}</p>
              ))}
            </div>
          </div>
        </motion.div>
      </TabsContent>

      <TabsContent value="clauses" className="mt-4">
        <div className="grid gap-4 sm:grid-cols-2">
          {Object.entries(analysis.clauses || {}).map(([key, items]) =>
            (items as ClauseItem[])?.length > 0 ? (
              <div key={key} className="space-y-2">
                <h3 className="text-sm font-semibold text-[#6366F1]">{clauseLabels[key] || key}</h3>
                {(items as ClauseItem[]).map((item, i) => (
                  <ClauseCard key={i} item={item} />
                ))}
              </div>
            ) : null
          )}
        </div>
      </TabsContent>

      <TabsContent value="risk" className="mt-4 space-y-4">
        <RiskMeter
          score={risk?.overall_score ?? 50}
          level={risk?.overall_level ?? "medium"}
          locale={locale}
          clauseRisks={risk?.clause_risks}
        />
        {[
          { title: "Potential Risks", items: risk?.potential_risks, icon: FileWarning },
          { title: "Hidden Liabilities", items: risk?.hidden_liabilities, icon: Shield },
          { title: "Unfavorable Conditions", items: risk?.unfavorable_conditions, icon: FileWarning },
          { title: "Missing Protections", items: risk?.missing_protections, icon: Shield },
        ].map(({ title, items, icon: Icon }) =>
          items && items.length > 0 ? (
            <div key={title} className="glass rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2"><Icon className="h-4 w-4 text-amber-400" /><h4 className="font-medium text-sm">{title}</h4></div>
              <ul className="space-y-1">{items.map((x, i) => <li key={i} className="text-sm text-zinc-400">• {x}</li>)}</ul>
            </div>
          ) : null
        )}
      </TabsContent>

      <TabsContent value="obligations" className="mt-4 grid sm:grid-cols-2 gap-4">
        {(["party_a", "party_b"] as const).map((party) => (
          <div key={party} className="glass rounded-xl p-4">
            <h4 className="font-medium mb-3 capitalize">{party.replace("_", " ")}</h4>
            {(analysis.obligations?.[party] || []).map((o, i) => (
              <div key={i} className="text-sm text-zinc-400 mb-2 border-b border-white/5 pb-2 last:border-0">
                {o.description}
                {o.deadline && <span className="block text-xs text-[#00E5FF] mt-1">Due: {o.deadline}</span>}
              </div>
            ))}
          </div>
        ))}
        <div className="glass rounded-xl p-4 sm:col-span-2">
          <h4 className="font-medium mb-2">Deliverables</h4>
          <ul>{(analysis.obligations?.deliverables || []).map((d, i) => <li key={i} className="text-sm text-zinc-400">• {d}</li>)}</ul>
        </div>
      </TabsContent>

      <TabsContent value="insights" className="mt-4 space-y-4">
        {[
          { key: "implications", label: "Legal Implications" },
          { key: "considerations", label: "Considerations" },
          { key: "compliance_concerns", label: "Compliance" },
          { key: "recommended_actions", label: "Recommended Actions" },
        ].map(({ key, label }) => {
          const items = (analysis.legal_insights as Record<string, string[]>)?.[key] || [];
          if (!items.length) return null;
          return (
            <div key={key} className="glass rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2"><Lightbulb className="h-4 w-4 text-[#10B981]" /><h4 className="font-medium text-sm">{label}</h4></div>
              <ul className="space-y-1">{items.map((x, i) => <li key={i} className="text-sm text-zinc-400">• {x}</li>)}</ul>
            </div>
          );
        })}
      </TabsContent>

      <TabsContent value="recommendations" className="mt-4 space-y-4">
        {analysis.recommendations &&
          Object.entries({
            suggested_edits: "Suggested Edits",
            missing_clauses: "Missing Clauses",
            negotiation_points: "Negotiation Points",
          }).map(([key, label]) => {
            const items = (analysis.recommendations as Record<string, string[]>)?.[key] || [];
            if (!items.length) return null;
            return (
              <div key={key} className="glass rounded-xl p-4">
                <h4 className="font-medium text-sm mb-2">{label}</h4>
                <ul className="space-y-1">{items.map((x, i) => <li key={i} className="text-sm text-zinc-400">• {x}</li>)}</ul>
              </div>
            );
          })}
      </TabsContent>
    </Tabs>
  );
}
