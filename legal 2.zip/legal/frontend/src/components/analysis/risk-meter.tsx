"use client";

import { motion } from "framer-motion";
import type { RiskLevel } from "@/types/legal";
import { t, type Locale } from "@/lib/i18n";

const levelColors: Record<RiskLevel, string> = {
  low: "#10B981",
  medium: "#F59E0B",
  high: "#EF4444",
};

interface RiskMeterProps {
  score: number;
  level: RiskLevel;
  locale?: Locale;
  clauseRisks?: { clause: string; score: number; level: RiskLevel }[];
}

export function RiskMeter({ score, level, locale = "en", clauseRisks }: RiskMeterProps) {
  const color = levelColors[level] || levelColors.medium;
  const circumference = 2 * Math.PI * 54;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="glass rounded-2xl p-6 ai-glow">
      <h3 className="mb-4 text-lg font-semibold">{t("analysis.risk", locale)}</h3>
      <div className="flex flex-col items-center gap-4 sm:flex-row sm:gap-8">
        <div className="relative h-32 w-32 shrink-0">
          <svg className="h-32 w-32 -rotate-90" viewBox="0 0 120 120">
            <circle cx="60" cy="60" r="54" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="10" />
            <motion.circle
              cx="60"
              cy="60"
              r="54"
              fill="none"
              stroke={color}
              strokeWidth="10"
              strokeLinecap="round"
              strokeDasharray={circumference}
              initial={{ strokeDashoffset: circumference }}
              animate={{ strokeDashoffset: offset }}
              transition={{ duration: 1.2, ease: "easeOut" }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-2xl font-bold" style={{ color }}>
              {score}
            </span>
            <span className="text-xs text-zinc-500">/ 100</span>
          </div>
        </div>
        <div className="flex-1 text-center sm:text-left">
          <span
            className="inline-block rounded-full px-4 py-1 text-sm font-medium capitalize"
            style={{ backgroundColor: `${color}22`, color }}
          >
            {t(`risk.${level}`, locale)}
          </span>
          <p className="mt-2 text-sm text-zinc-400">
            Overall contract risk based on AI analysis of clauses, liabilities, and missing protections.
          </p>
        </div>
      </div>
      {clauseRisks && clauseRisks.length > 0 && (
        <div className="mt-6 space-y-2 border-t border-white/5 pt-4">
          {clauseRisks.map((c, i) => (
            <div key={i} className="flex items-center justify-between text-sm">
              <span className="text-zinc-300 truncate max-w-[60%]">{c.clause}</span>
              <div className="flex items-center gap-2">
                <div className="h-1.5 w-24 rounded-full bg-white/5 overflow-hidden">
                  <motion.div
                    className="h-full rounded-full"
                    style={{ backgroundColor: levelColors[c.level] }}
                    initial={{ width: 0 }}
                    animate={{ width: `${c.score}%` }}
                    transition={{ delay: i * 0.1 }}
                  />
                </div>
                <span className="text-zinc-500 w-8 text-right">{c.score}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
