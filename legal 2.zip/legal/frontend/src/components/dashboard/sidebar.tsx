"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import {
  LayoutDashboard,
  Upload,
  FileText,
  MessageSquare,
  GitCompare,
  FileOutput,
  Scale,
  LogOut,
} from "lucide-react";
import { cn } from "@/lib/utils";

const links = [
  { href: "/dashboard", icon: LayoutDashboard, label: "Overview" },
  { href: "/dashboard/upload", icon: Upload, label: "Upload" },
  { href: "/dashboard/analysis", icon: FileText, label: "Analysis" },
  { href: "/dashboard/chat", icon: MessageSquare, label: "Chat" },
  { href: "/dashboard/compare", icon: GitCompare, label: "Compare" },
  { href: "/dashboard/reports", icon: FileOutput, label: "Reports" },
];

export function DashboardSidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden lg:flex w-64 flex-col glass border-r border-white/5 min-h-screen">
      <div className="p-6 flex items-center gap-2">
        <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-[#7C3AED] to-[#6366F1] flex items-center justify-center">
          <Scale className="h-5 w-5 text-white" />
        </div>
        <span className="font-bold gradient-text">LegalAI</span>
      </div>
      <nav className="flex-1 px-3 space-y-1">
        {links.map((link) => {
          const active = pathname === link.href;
          return (
            <Link key={link.href} href={link.href}>
              <motion.span
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-colors",
                  active ? "bg-[#7C3AED]/20 text-white" : "text-zinc-400 hover:text-white hover:bg-white/5"
                )}
                whileHover={{ x: 4 }}
              >
                <link.icon className="h-4 w-4" />
                {link.label}
              </motion.span>
            </Link>
          );
        })}
      </nav>
      <div className="p-3 border-t border-white/5">
        <Link href="/auth/login" className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-zinc-400 hover:text-white">
          <LogOut className="h-4 w-4" />
          Sign In
        </Link>
      </div>
    </aside>
  );
}
