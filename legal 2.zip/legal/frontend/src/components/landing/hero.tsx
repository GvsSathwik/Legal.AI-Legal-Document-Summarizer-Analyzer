"use client";

import { motion } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";
import { LinkButton } from "@/components/ui/link-button";
import { useAppStore } from "@/store/app-store";
import { t } from "@/lib/i18n";

export function Hero() {
  const { locale } = useAppStore();

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center pt-24 pb-16 overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute h-1 w-1 rounded-full bg-[#7C3AED]/40"
            style={{ left: `${(i * 17) % 100}%`, top: `${(i * 23) % 100}%` }}
            animate={{ opacity: [0.2, 0.8, 0.2], scale: [1, 1.5, 1] }}
            transition={{ duration: 3 + (i % 5), repeat: Infinity, delay: i * 0.2 }}
          />
        ))}
        <motion.div
          className="absolute top-1/4 left-1/2 -translate-x-1/2 h-96 w-96 rounded-full bg-[#7C3AED]/20 blur-[120px]"
          animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
          transition={{ duration: 8, repeat: Infinity }}
        />
      </div>

      <div className="relative z-10 mx-auto max-w-4xl px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 text-sm mb-8"
        >
          <Sparkles className="h-4 w-4 text-[#00E5FF]" />
          <span className="text-zinc-400">Powered by Gemini, Groq & Hugging Face</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-4xl sm:text-6xl lg:text-7xl font-bold tracking-tight"
        >
          <span className="gradient-text">{t("hero.title", locale)}</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mt-6 text-lg sm:text-xl text-zinc-400 max-w-2xl mx-auto"
        >
          {t("hero.subtitle", locale)}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-10 flex flex-col sm:flex-row gap-4 justify-center"
        >
          <LinkButton size="lg" href="/dashboard" className="bg-gradient-to-r from-[#7C3AED] to-[#6366F1] text-lg h-12 px-8 ai-glow">
            {t("hero.cta", locale)}
            <ArrowRight className="ml-2 h-5 w-5" />
          </LinkButton>
          <LinkButton size="lg" variant="outline" href="/dashboard?demo=1" className="h-12 px-8 glass border-white/10">
            {t("hero.demo", locale)}
          </LinkButton>
        </motion.div>
      </div>
    </section>
  );
}
