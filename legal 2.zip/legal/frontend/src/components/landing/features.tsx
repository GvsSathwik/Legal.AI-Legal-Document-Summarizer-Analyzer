"use client";

import { motion } from "framer-motion";
import { FileSearch, ShieldAlert, MessageSquare, GitCompare, Globe, FileDown } from "lucide-react";

const features = [
  { icon: FileSearch, title: "Smart Analysis", desc: "Executive summaries, clause extraction, and obligation mapping in seconds." },
  { icon: ShieldAlert, title: "Risk Meter", desc: "Visual risk scoring with clause-by-clause breakdown and liability detection." },
  { icon: MessageSquare, title: "Document Chat", desc: "RAG-powered Q&A — ask anything about your contract in plain language." },
  { icon: GitCompare, title: "Compare Contracts", desc: "Upload two documents and get side-by-side risk and clause comparison." },
  { icon: Globe, title: "Multi-Language", desc: "Analysis and UI in English, Hindi, and Telugu." },
  { icon: FileDown, title: "Export Reports", desc: "Download PDF summaries, full analysis, and risk assessment reports." },
];

export function Features() {
  return (
    <section id="features" className="py-24 px-4">
      <div className="mx-auto max-w-6xl">
        <motion.h2
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-3xl font-bold text-center mb-4"
        >
          Everything you need for <span className="gradient-text">legal intelligence</span>
        </motion.h2>
        <p className="text-zinc-500 text-center mb-16 max-w-xl mx-auto">
          Enterprise-grade AI analysis built on free-tier APIs. Secure, fast, and production-ready.
        </p>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="glass rounded-2xl p-6 hover:border-[#7C3AED]/30 border border-transparent transition-colors group"
            >
              <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-[#7C3AED]/30 to-[#00E5FF]/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <f.icon className="h-6 w-6 text-[#00E5FF]" />
              </div>
              <h3 className="font-semibold mb-2">{f.title}</h3>
              <p className="text-sm text-zinc-500">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
