"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Bot, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { chatWithDocument } from "@/lib/api";
import { useAppStore } from "@/store/app-store";
import { t } from "@/lib/i18n";
import type { ChatMessage } from "@/types/legal";
import { AIThinking } from "@/components/ui/ai-thinking";

const SUGGESTIONS = [
  "What are the termination conditions?",
  "Summarize payment obligations.",
  "Who is liable in case of breach?",
  "What risks exist in this contract?",
];

export function DocumentChat({ documentText }: { documentText: string }) {
  const { locale } = useAppStore();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const send = async (question: string) => {
    if (!question.trim() || !documentText) return;
    const userMsg: ChatMessage = { id: crypto.randomUUID(), role: "user", content: question };
    setMessages((m) => [...m, userMsg]);
    setInput("");
    setLoading(true);
    try {
      const res = await chatWithDocument(documentText, question, locale);
      setMessages((m) => [
        ...m,
        {
          id: crypto.randomUUID(),
          role: "assistant",
          content: res.answer,
          sources: res.sources,
        },
      ]);
    } catch (e) {
      setMessages((m) => [
        ...m,
        {
          id: crypto.randomUUID(),
          role: "assistant",
          content: e instanceof Error ? e.message : "Failed to get response",
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="glass rounded-2xl flex flex-col h-[500px]">
      <div className="p-4 border-b border-white/5">
        <h3 className="font-semibold flex items-center gap-2">
          <Bot className="h-5 w-5 text-[#7C3AED]" />
          AI Document Chat
        </h3>
        <p className="text-xs text-zinc-500 mt-1">RAG-powered answers from your document</p>
      </div>

      <ScrollArea className="flex-1 p-4">
        {messages.length === 0 && (
          <div className="flex flex-wrap gap-2">
            {SUGGESTIONS.map((s) => (
              <button
                key={s}
                onClick={() => send(s)}
                className="text-xs glass rounded-full px-3 py-1.5 hover:border-[#7C3AED]/50 border border-white/5 transition-colors"
              >
                {s}
              </button>
            ))}
          </div>
        )}
        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex gap-3 mb-4 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
            >
              <div className={`shrink-0 h-8 w-8 rounded-lg flex items-center justify-center ${msg.role === "user" ? "bg-[#6366F1]/30" : "bg-[#7C3AED]/30"}`}>
                {msg.role === "user" ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
              </div>
              <div className={`max-w-[85%] rounded-xl px-4 py-2 text-sm ${msg.role === "user" ? "bg-[#6366F1]/20" : "glass"}`}>
                <p className="text-zinc-300 whitespace-pre-wrap">{msg.content}</p>
                {msg.sources && msg.sources.length > 0 && (
                  <p className="text-xs text-zinc-600 mt-2">Sources: chunks {msg.sources.map((s) => s.index + 1).join(", ")}</p>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        {loading && <AIThinking label="Searching document context..." />}
      </ScrollArea>

      <div className="p-4 border-t border-white/5 flex gap-2">
        <Textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={t("chat.placeholder", locale)}
          className="min-h-[44px] max-h-24 resize-none glass"
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              send(input);
            }
          }}
        />
        <Button
          size="icon"
          onClick={() => send(input)}
          disabled={loading || !input.trim()}
          className="shrink-0 bg-gradient-to-r from-[#7C3AED] to-[#6366F1]"
        >
          <Send className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
