"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Scale, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { LinkButton } from "@/components/ui/link-button";
import { useAppStore } from "@/store/app-store";
import { locales, t } from "@/lib/i18n";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export function Navbar() {
  const { locale, setLocale } = useAppStore();

  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed top-0 z-50 w-full border-b border-white/5 glass"
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-[#7C3AED] to-[#6366F1]">
            <Scale className="h-5 w-5 text-white" />
          </div>
          <span className="text-lg font-bold gradient-text">LegalAI</span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          <Link href="/#features" className="text-sm text-zinc-400 hover:text-white transition-colors">
            {t("nav.features", locale)}
          </Link>
          <Link href="/#pricing" className="text-sm text-zinc-400 hover:text-white transition-colors">
            {t("nav.pricing", locale)}
          </Link>
        </nav>

        <div className="flex items-center gap-3">
          <Select value={locale} onValueChange={(v) => setLocale(v as typeof locale)}>
            <SelectTrigger className="w-[110px] h-9 glass border-white/10">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {locales.map((l) => (
                <SelectItem key={l.code} value={l.code}>
                  {l.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <LinkButton variant="ghost" size="sm" href="/auth/login" className="hidden sm:inline-flex">
            {t("nav.login", locale)}
          </LinkButton>
          <LinkButton size="sm" href="/dashboard" className="bg-gradient-to-r from-[#7C3AED] to-[#6366F1] hover:opacity-90">
            {t("nav.dashboard", locale)}
          </LinkButton>
          <Button variant="ghost" size="icon" className="md:hidden">
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </motion.header>
  );
}
