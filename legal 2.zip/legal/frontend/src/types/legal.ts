export type RiskLevel = "low" | "medium" | "high";

export interface ClauseItem {
  title: string;
  excerpt: string;
  risk: RiskLevel;
}

export interface ExecutiveSummary {
  plain_english: string;
  purpose: string;
  main_obligations: string[];
  important_dates: { label: string; date: string }[];
  parties: { name: string; role: string }[];
}

export interface RiskAnalysis {
  overall_level: RiskLevel;
  overall_score: number;
  potential_risks?: string[];
  hidden_liabilities?: string[];
  unfavorable_conditions?: string[];
  missing_protections?: string[];
  clause_risks?: { clause: string; score: number; level: RiskLevel }[];
}

export interface LegalAnalysis {
  executive_summary: ExecutiveSummary;
  clauses: Record<string, ClauseItem[]>;
  risk_analysis: RiskAnalysis;
  obligations: {
    party_a: { description: string; deadline: string | null }[];
    party_b: { description: string; deadline: string | null }[];
    deliverables: string[];
  };
  legal_insights: {
    implications: string[];
    considerations: string[];
    compliance_concerns: string[];
    recommended_actions: string[];
  };
  recommendations?: {
    suggested_edits: string[];
    missing_clauses: string[];
    negotiation_points: string[];
  };
  _meta?: { provider?: string; parse_error?: boolean };
}

export interface DocumentRecord {
  id: string;
  title: string;
  filename: string;
  file_type: string;
  status: string;
  word_count?: number;
  created_at: string;
  extracted_text?: string;
}

export interface ParseResult {
  text: string;
  char_count: number;
  word_count: number;
  method: string;
  filename: string;
  chunks?: { id: string; index: number; content: string }[];
  chunk_count?: number;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  sources?: { index: number; preview: string }[];
}
