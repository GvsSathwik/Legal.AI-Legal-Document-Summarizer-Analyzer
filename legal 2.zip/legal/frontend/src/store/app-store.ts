import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { LegalAnalysis, ParseResult } from "@/types/legal";
import type { Locale } from "@/lib/i18n";

interface AppState {
  locale: Locale;
  setLocale: (l: Locale) => void;
  currentParse: ParseResult | null;
  setCurrentParse: (p: ParseResult | null) => void;
  currentAnalysis: LegalAnalysis | null;
  setCurrentAnalysis: (a: LegalAnalysis | null) => void;
  compareParseA: ParseResult | null;
  compareParseB: ParseResult | null;
  setCompareParseA: (p: ParseResult | null) => void;
  setCompareParseB: (p: ParseResult | null) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      locale: "en",
      setLocale: (locale) => set({ locale }),
      currentParse: null,
      setCurrentParse: (currentParse) => set({ currentParse }),
      currentAnalysis: null,
      setCurrentAnalysis: (currentAnalysis) => set({ currentAnalysis }),
      compareParseA: null,
      compareParseB: null,
      setCompareParseA: (compareParseA) => set({ compareParseA }),
      setCompareParseB: (compareParseB) => set({ compareParseB }),
    }),
    { name: "legalai-store", partialize: (s) => ({ locale: s.locale }) }
  )
);
