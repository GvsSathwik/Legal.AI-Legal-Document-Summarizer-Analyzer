import type { ParseResult } from "@/types/legal";

/** Browser uses Next.js proxy to avoid CORS; server uses direct backend URL. */
function getBackendUrl(): string {
  if (typeof window !== "undefined") {
    return "/api/backend";
  }
  return process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000";
}

export async function parseDocument(
  file: File,
  forceOcr = false
): Promise<ParseResult> {
  const form = new FormData();
  form.append("file", file);
  form.append("force_ocr", String(forceOcr));
  const res = await fetch(`${getBackendUrl()}/documents/parse`, {
    method: "POST",
    body: form,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error((err as { detail?: string }).detail || "Parse failed");
  }
  return res.json() as Promise<ParseResult>;
}

export async function analyzeDocument(
  text: string,
  language = "en"
): Promise<import("@/types/legal").LegalAnalysis> {
  const form = new FormData();
  form.append("text", text);
  form.append("language", language);
  const res = await fetch(`${getBackendUrl()}/documents/analyze`, {
    method: "POST",
    body: form,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error((err as { detail?: string }).detail || "Analysis failed");
  }
  return res.json() as Promise<import("@/types/legal").LegalAnalysis>;
}

export async function chatWithDocument(
  text: string,
  question: string,
  language = "en"
): Promise<{ answer: string; sources?: { index: number; preview: string }[]; provider?: string }> {
  const form = new FormData();
  form.append("text", text);
  form.append("question", question);
  form.append("language", language);
  const res = await fetch(`${getBackendUrl()}/documents/chat`, {
    method: "POST",
    body: form,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error((err as { detail?: string }).detail || "Chat failed");
  }
  return res.json();
}

export async function compareDocuments(
  textA: string,
  textB: string
): Promise<Record<string, unknown>> {
  const form = new FormData();
  form.append("text_a", textA);
  form.append("text_b", textB);
  const res = await fetch(`${getBackendUrl()}/documents/compare`, {
    method: "POST",
    body: form,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error((err as { detail?: string }).detail || "Compare failed");
  }
  return res.json();
}
