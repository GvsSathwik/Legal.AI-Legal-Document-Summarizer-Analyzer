import { jsPDF } from "jspdf";
import type { LegalAnalysis } from "@/types/legal";

export function exportAnalysisPdf(
  title: string,
  analysis: LegalAnalysis,
  type: "summary" | "full" | "risk" = "full"
) {
  const doc = new jsPDF();
  const margin = 20;
  let y = margin;
  const lineHeight = 7;
  const pageWidth = doc.internal.pageSize.getWidth();

  const addLine = (text: string, size = 10, bold = false) => {
    doc.setFontSize(size);
    doc.setFont("helvetica", bold ? "bold" : "normal");
    const lines = doc.splitTextToSize(text, pageWidth - margin * 2);
    for (const line of lines) {
      if (y > doc.internal.pageSize.getHeight() - margin) {
        doc.addPage();
        y = margin;
      }
      doc.text(line, margin, y);
      y += lineHeight;
    }
  };

  addLine("LegalAI Analysis Report", 18, true);
  addLine(title, 12);
  addLine(`Generated: ${new Date().toLocaleString()}`, 9);
  y += 5;

  if (type === "summary" || type === "full") {
    addLine("Executive Summary", 14, true);
    addLine(analysis.executive_summary?.plain_english || "N/A");
    addLine(`Purpose: ${analysis.executive_summary?.purpose || "N/A"}`);
    y += 3;
  }

  if (type === "risk" || type === "full") {
    addLine("Risk Assessment", 14, true);
    const risk = analysis.risk_analysis;
    addLine(
      `Overall: ${risk?.overall_level?.toUpperCase() || "N/A"} (Score: ${risk?.overall_score ?? "N/A"}/100)`
    );
    (risk?.potential_risks || []).forEach((r) => addLine(`• ${r}`));
    y += 3;
  }

  if (type === "full") {
    addLine("Key Obligations", 14, true);
    (analysis.executive_summary?.main_obligations || []).forEach((o) =>
      addLine(`• ${o}`)
    );
    addLine("Recommended Actions", 14, true);
    (analysis.legal_insights?.recommended_actions || []).forEach((a) =>
      addLine(`• ${a}`)
    );
  }

  addLine("", 10);
  addLine("Disclaimer: This report is AI-generated and not legal advice.", 8);

  doc.save(`legalai-${type}-${Date.now()}.pdf`);
}
