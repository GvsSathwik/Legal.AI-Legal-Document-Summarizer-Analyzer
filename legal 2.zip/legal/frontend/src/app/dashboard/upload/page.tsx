"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Sparkles, Download } from "lucide-react";
import { toast } from "sonner";
import { DocumentUpload } from "@/components/upload/document-upload";
import { AnalysisPanel } from "@/components/analysis/analysis-panel";
import { AIThinking } from "@/components/ui/ai-thinking";
import { Button } from "@/components/ui/button";
import { analyzeDocument } from "@/lib/api";
import { exportAnalysisPdf } from "@/lib/export-report";
import { useAppStore } from "@/store/app-store";
import { t } from "@/lib/i18n";
import type { LegalAnalysis, ParseResult } from "@/types/legal";

export default function UploadPage() {
  const { locale, setCurrentAnalysis, currentAnalysis } = useAppStore();
  const [analyzing, setAnalyzing] = useState(false);
  const [parsed, setParsed] = useState<ParseResult | null>(null);

  const runAnalysis = async (text: string) => {
    setAnalyzing(true);
    try {
      const result = await analyzeDocument(text, locale);
      setCurrentAnalysis(result);
      toast.success("Analysis complete");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Analysis failed");
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold">{t("upload.title", locale)}</h1>
        <p className="text-zinc-500 mt-1">Upload PDF, DOCX, or TXT for AI legal analysis</p>
      </div>

      <DocumentUpload
        onParsed={(result) => {
          setParsed(result);
        }}
      />

      {parsed && !analyzing && !currentAnalysis && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <Button
            size="lg"
            className="w-full sm:w-auto bg-gradient-to-r from-[#7C3AED] to-[#6366F1]"
            onClick={() => runAnalysis(parsed.text)}
          >
            <Sparkles className="h-4 w-4 mr-2" />
            Run AI Legal Analysis
          </Button>
        </motion.div>
      )}

      {analyzing && <AIThinking label="AI is analyzing clauses, risks, and obligations..." />}

      {currentAnalysis && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <div className="flex flex-wrap gap-2 justify-end">
            <Button
              variant="outline"
              size="sm"
              className="glass"
              onClick={() =>
                exportAnalysisPdf(parsed?.filename || "document", currentAnalysis, "summary")
              }
            >
              <Download className="h-4 w-4 mr-1" />
              {t("export.pdf", locale)}
            </Button>
          </div>
          <AnalysisPanel analysis={currentAnalysis} />
        </motion.div>
      )}
    </div>
  );
}
