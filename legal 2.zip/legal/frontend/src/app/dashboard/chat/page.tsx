"use client";

import { DocumentChat } from "@/components/chat/document-chat";
import { LinkButton } from "@/components/ui/link-button";
import { useAppStore } from "@/store/app-store";

export default function ChatPage() {
  const { currentParse } = useAppStore();

  if (!currentParse?.text) {
    return (
      <div className="max-w-lg mx-auto text-center py-20 glass rounded-2xl">
        <h2 className="text-xl font-semibold mb-2">No document loaded</h2>
        <p className="text-zinc-500 mb-6">Upload a document to start chatting with it.</p>
        <LinkButton href="/dashboard/upload" className="bg-gradient-to-r from-[#7C3AED] to-[#6366F1]">
          Upload Document
        </LinkButton>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Document Chat</h1>
        <p className="text-zinc-500 text-sm mt-1">Chatting with: {currentParse.filename}</p>
      </div>
      <DocumentChat documentText={currentParse.text} />
    </div>
  );
}
