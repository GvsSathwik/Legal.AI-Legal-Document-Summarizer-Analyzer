"use client";

import { FileDown } from "lucide-react";
import { LinkButton } from "@/components/ui/link-button";
import { Button } from "@/components/ui/button";
import { exportAnalysisPdf } from "@/lib/export-report";
import { useAppStore } from "@/store/app-store";
import { t } from "@/lib/i18n";

export default function ReportsPage() {
  const { currentAnalysis, currentParse, locale } = useAppStore();
  const title = currentParse?.filename || "Legal Document";

  if (!currentAnalysis) {
    return (
      <div className="max-w-lg mx-auto text-center py-20 glass rounded-2xl">
        <h2 className="text-xl font-semibold mb-2">No report available</h2>
        <p className="text-zinc-500 mb-6">Complete an analysis to export reports.</p>
        <LinkButton href="/dashboard/upload" className="bg-gradient-to-r from-[#7C3AED] to-[#6366F1]">
          Upload & Analyze
        </LinkButton>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Export Reports</h1>
        <p className="text-zinc-500 mt-1">Download PDF reports for {title}</p>
      </div>
      <div className="grid gap-4">
        {(
          [
            { type: "summary" as const, label: "PDF Summary", desc: "Executive summary and key points" },
            { type: "full" as const, label: "Full Legal Analysis", desc: "Complete analysis report" },
            { type: "risk" as const, label: "Risk Assessment", desc: "Risk scores and liabilities" },
          ] as const
        ).map((r) => (
          <div key={r.type} className="glass rounded-xl p-5 flex items-center justify-between">
            <div>
              <h3 className="font-medium">{r.label}</h3>
              <p className="text-sm text-zinc-500">{r.desc}</p>
            </div>
            <Button
              variant="outline"
              className="glass"
              onClick={() => exportAnalysisPdf(title, currentAnalysis, r.type)}
            >
              <FileDown className="h-4 w-4 mr-2" />
              {t("export.pdf", locale)}
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}
