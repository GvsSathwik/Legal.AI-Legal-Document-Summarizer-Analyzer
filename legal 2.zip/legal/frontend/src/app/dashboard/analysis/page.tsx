"use client";

import { AnalysisPanel } from "@/components/analysis/analysis-panel";
import { LinkButton } from "@/components/ui/link-button";
import { useAppStore } from "@/store/app-store";
import { t } from "@/lib/i18n";

export default function AnalysisPage() {
  const { currentAnalysis, locale } = useAppStore();

  if (!currentAnalysis) {
    return (
      <div className="max-w-lg mx-auto text-center py-20 glass rounded-2xl">
        <h2 className="text-xl font-semibold mb-2">No analysis yet</h2>
        <p className="text-zinc-500 mb-6">Upload a document and run AI analysis first.</p>
        <LinkButton href="/dashboard/upload" className="bg-gradient-to-r from-[#7C3AED] to-[#6366F1]">
          {t("upload.title", locale)}
        </LinkButton>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Legal Analysis</h1>
      <AnalysisPanel analysis={currentAnalysis} />
    </div>
  );
}
