"use client";

import { motion } from "framer-motion";
import { FileText, BarChart3, AlertTriangle, Zap } from "lucide-react";
import { LinkButton } from "@/components/ui/link-button";
import { useAppStore } from "@/store/app-store";
import { t } from "@/lib/i18n";

export default function DashboardPage() {
  const { locale, currentParse, currentAnalysis } = useAppStore();

  const stats = [
    { label: t("dashboard.documents", locale), value: currentParse ? "1" : "0", icon: FileText, color: "#7C3AED" },
    { label: t("dashboard.analyses", locale), value: currentAnalysis ? "1" : "0", icon: BarChart3, color: "#6366F1" },
    {
      label: t("dashboard.risk", locale),
      value: currentAnalysis?.risk_analysis?.overall_score?.toString() ?? "—",
      icon: AlertTriangle,
      color: "#F59E0B",
    },
    { label: t("dashboard.usage", locale), value: "—", icon: Zap, color: "#00E5FF" },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold">{t("dashboard.title", locale)}</h1>
        <p className="text-zinc-500 mt-1">Manage documents, analyses, and AI insights</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="glass rounded-2xl p-5"
          >
            <div className="flex items-center justify-between">
              <s.icon className="h-5 w-5" style={{ color: s.color }} />
              <span className="text-2xl font-bold">{s.value}</span>
            </div>
            <p className="text-sm text-zinc-500 mt-2">{s.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="glass rounded-2xl p-6">
        <h2 className="font-semibold mb-4">Quick Actions</h2>
        <div className="flex flex-wrap gap-3">
          <LinkButton href="/dashboard/upload" className="bg-gradient-to-r from-[#7C3AED] to-[#6366F1]">
            Upload Document
          </LinkButton>
          <LinkButton href="/dashboard/analysis" variant="outline" className="glass border-white/10">
            View Analysis
          </LinkButton>
          <LinkButton href="/dashboard/compare" variant="outline" className="glass border-white/10">
            Compare Contracts
          </LinkButton>
        </div>
      </div>

      {currentParse && (
        <div className="glass rounded-2xl p-6">
          <h2 className="font-semibold mb-2">Recent Document</h2>
          <p className="text-sm text-zinc-400">{currentParse.filename}</p>
          <p className="text-xs text-zinc-600 mt-1">
            {currentParse.word_count} words · uploaded in this session
          </p>
        </div>
      )}
    </div>
  );
}
