"use client";

import { useState } from "react";
import { useDropzone } from "react-dropzone";
import { motion } from "framer-motion";
import { GitCompare, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { compareDocuments, parseDocument } from "@/lib/api";
import { AIThinking } from "@/components/ui/ai-thinking";
import { useAppStore } from "@/store/app-store";
import { t } from "@/lib/i18n";
import type { ParseResult } from "@/types/legal";

function CompareDrop({ label, onParsed }: { label: string; onParsed: (p: ParseResult) => void }) {
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: async (files) => {
      if (files[0]) {
        const r = await parseDocument(files[0]);
        onParsed(r);
      }
    },
    maxFiles: 1,
    accept: {
      "application/pdf": [".pdf"],
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
      "text/plain": [".txt"],
    },
  });

  return (
    <div
      {...getRootProps()}
      className={`glass rounded-xl border-2 border-dashed p-8 text-center cursor-pointer ${
        isDragActive ? "border-[#00E5FF]" : "border-white/10"
      }`}
    >
      <input {...getInputProps()} />
      <Upload className="h-8 w-8 mx-auto text-[#7C3AED] mb-2" />
      <p className="font-medium">{label}</p>
      <p className="text-xs text-zinc-500 mt-1">PDF, DOCX, TXT</p>
    </div>
  );
}

export default function ComparePage() {
  const { locale, compareParseA, compareParseB, setCompareParseA, setCompareParseB } = useAppStore();
  const [loading, setLoading] = useState(false);
  interface CompareResult {
    summary?: string;
    risk_comparison?: { doc_a_level?: string; doc_b_level?: string; notes?: string };
    key_differences?: { topic: string; document_a: string; document_b: string }[];
    clause_comparison?: { clause_type: string; similarity: string; notes: string }[];
  }
  const [result, setResult] = useState<CompareResult | null>(null);

  const runCompare = async () => {
    if (!compareParseA?.text || !compareParseB?.text) return;
    setLoading(true);
    try {
      const res = await compareDocuments(compareParseA.text, compareParseB.text);
      setResult(res as CompareResult);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <GitCompare className="h-8 w-8 text-[#7C3AED]" />
          {t("compare.title", locale)}
        </h1>
        <p className="text-zinc-500 mt-1">Upload two contracts for AI-powered comparison</p>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <CompareDrop label="Document A" onParsed={setCompareParseA} />
          {compareParseA && <p className="text-xs text-zinc-500 mt-2 truncate">{compareParseA.filename}</p>}
        </div>
        <div>
          <CompareDrop label="Document B" onParsed={setCompareParseB} />
          {compareParseB && <p className="text-xs text-zinc-500 mt-2 truncate">{compareParseB.filename}</p>}
        </div>
      </div>

      <Button
        disabled={!compareParseA || !compareParseB || loading}
        onClick={runCompare}
        className="bg-gradient-to-r from-[#7C3AED] to-[#6366F1]"
      >
        Compare Documents
      </Button>

      {loading && <AIThinking label="Comparing contracts..." />}

      {result && !loading && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass rounded-2xl p-6 space-y-4">
          <p className="text-zinc-300">{result.summary || "Comparison complete."}</p>
          {result.risk_comparison && (
            <div className="grid sm:grid-cols-2 gap-4 text-sm">
              <div className="glass rounded-lg p-3">
                <span className="text-zinc-500">Doc A Risk:</span>{" "}
                <strong>{result.risk_comparison.doc_a_level}</strong>
              </div>
              <div className="glass rounded-lg p-3">
                <span className="text-zinc-500">Doc B Risk:</span>{" "}
                <strong>{result.risk_comparison.doc_b_level}</strong>
              </div>
            </div>
          )}
          {result.key_differences?.map(
            (d, i) => (
              <div key={i} className="border-t border-white/5 pt-3">
                <h4 className="font-medium text-[#00E5FF]">{d.topic}</h4>
                <p className="text-sm text-zinc-400 mt-1">A: {d.document_a}</p>
                <p className="text-sm text-zinc-400">B: {d.document_b}</p>
              </div>
            )
          )}
        </motion.div>
      )}
    </div>
  );
}
