"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Scale } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { createClient } from "@/lib/supabase/client";
import { toast } from "sonner";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  const signInGoogle = async () => {
    const supabase = createClient();
    if (!process.env.NEXT_PUBLIC_SUPABASE_URL) {
      toast.info("Configure Supabase in .env.local to enable Google login");
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: `${window.location.origin}/auth/callback`,
      },
    });
    if (error) toast.error(error.message);
    setLoading(false);
  };

  const signInEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    const supabase = createClient();
    if (!process.env.NEXT_PUBLIC_SUPABASE_URL) {
      toast.info("Configure Supabase to enable auth. You can use the dashboard without login.");
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.signInWithOtp({ email });
    if (error) toast.error(error.message);
    else toast.success("Check your email for the magic link");
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-2xl p-8 w-full max-w-md ai-glow"
      >
        <Link href="/" className="flex items-center justify-center gap-2 mb-8">
          <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-[#7C3AED] to-[#6366F1] flex items-center justify-center">
            <Scale className="h-6 w-6 text-white" />
          </div>
          <span className="text-xl font-bold gradient-text">LegalAI</span>
        </Link>

        <h1 className="text-2xl font-bold text-center mb-2">Welcome back</h1>
        <p className="text-zinc-500 text-center text-sm mb-8">Sign in to save documents and history</p>

        <Button
          className="w-full mb-4 bg-white text-black hover:bg-zinc-200"
          onClick={signInGoogle}
          disabled={loading}
        >
          Continue with Google
        </Button>

        <div className="relative my-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-white/10" />
          </div>
          <div className="relative flex justify-center text-xs">
            <span className="bg-transparent px-2 text-zinc-500">or email</span>
          </div>
        </div>

        <form onSubmit={signInEmail} className="space-y-4">
          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@company.com"
              className="glass mt-1"
              required
            />
          </div>
          <Button type="submit" className="w-full bg-gradient-to-r from-[#7C3AED] to-[#6366F1]" disabled={loading}>
            Send Magic Link
          </Button>
        </form>

        <p className="text-center text-sm text-zinc-500 mt-6">
          <Link href="/dashboard" className="text-[#00E5FF] hover:underline">
            Continue without signing in →
          </Link>
        </p>
      </motion.div>
    </div>
  );
}
