import { Navbar } from "@/components/layout/navbar";
import { Hero } from "@/components/landing/hero";
import { Features } from "@/components/landing/features";

export default function HomePage() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <Features />
        <section id="pricing" className="py-24 px-4 border-t border-white/5">
          <div className="mx-auto max-w-3xl text-center glass rounded-2xl p-12">
            <h2 className="text-2xl font-bold mb-2">Pricing</h2>
            <p className="text-zinc-500 mb-6">Free tier during beta. Enterprise plans coming soon.</p>
            <div className="inline-block rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#6366F1] px-8 py-4 text-3xl font-bold">
              $0 <span className="text-lg font-normal text-white/80">/ month</span>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t border-white/5 py-8 text-center text-sm text-zinc-600">
        © {new Date().getFullYear()} LegalAI. AI-generated insights are not legal advice.
      </footer>
    </>
  );
}
