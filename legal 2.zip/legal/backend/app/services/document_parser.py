import io
import re
from pathlib import Path
from typing import Optional

import pdfplumber
from docx import Document
from PyPDF2 import PdfReader


def extract_text_from_pdf(data: bytes, use_ocr: bool = False) -> str:
    text_parts: list[str] = []
    try:
        with pdfplumber.open(io.BytesIO(data)) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text() or ""
                if page_text.strip():
                    text_parts.append(page_text)
    except Exception:
        pass

    if not "".join(text_parts).strip():
        reader = PdfReader(io.BytesIO(data))
        for page in reader.pages:
            t = page.extract_text() or ""
            if t.strip():
                text_parts.append(t)

    combined = "\n\n".join(text_parts).strip()
    if not combined and use_ocr:
        combined = _ocr_pdf(data)
    return combined or ""


def _ocr_pdf(data: bytes) -> str:
    try:
        from pdf2image import convert_from_bytes
        import pytesseract

        images = convert_from_bytes(data, dpi=200)
        return "\n\n".join(pytesseract.image_to_string(img) for img in images)
    except Exception:
        return ""


def extract_text_from_docx(data: bytes) -> str:
    doc = Document(io.BytesIO(data))
    return "\n\n".join(p.text for p in doc.paragraphs if p.text.strip())


def extract_text_from_txt(data: bytes) -> str:
    for encoding in ("utf-8", "latin-1", "cp1252"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def parse_document(filename: str, data: bytes, force_ocr: bool = False) -> dict:
    ext = Path(filename).suffix.lower()
    text = ""
    method = "text"

    if ext == ".pdf":
        text = extract_text_from_pdf(data, use_ocr=force_ocr)
        method = "ocr" if force_ocr and text else "pdf"
    elif ext in (".docx", ".doc"):
        text = extract_text_from_docx(data)
        method = "docx"
    elif ext == ".txt":
        text = extract_text_from_txt(data)
        method = "txt"
    else:
        raise ValueError(f"Unsupported file type: {ext}")

    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    if not text:
        raise ValueError("Could not extract text from document. Try enabling OCR for scanned PDFs.")

    return {
        "text": text,
        "char_count": len(text),
        "word_count": len(text.split()),
        "method": method,
        "filename": filename,
    }
