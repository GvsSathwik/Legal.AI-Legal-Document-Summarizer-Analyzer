import json
import re
from typing import Any, Optional

import httpx

from app.core.config import get_settings


class AIProviderError(Exception):
    pass


# Groq free tier: ~12k tokens/min per request — keep total input under this
GROQ_MAX_INPUT_CHARS = 28_000


def _smart_truncate(text: str, max_chars: int) -> str:
    """Keep start and end of long legal docs (terms often at both ends)."""
    if len(text) <= max_chars:
        return text
    marker = (
        "\n\n[... middle of document omitted — analysis uses beginning and end only "
        "(Groq size limit). Upload a shorter file or add a valid Gemini AIzaSy key for "
        "longer documents.] ...\n\n"
    )
    remain = max(500, max_chars - len(marker))
    head = remain // 2
    tail = remain - head
    return text[:head] + marker + text[-tail:]


def _prepare_for_provider(prompt: str, system: str, provider: str) -> tuple[str, str]:
    if provider != "groq":
        return prompt, system
    max_total = GROQ_MAX_INPUT_CHARS
    overhead = len(system) + 4 if system else 0
    if len(prompt) + overhead <= max_total:
        return prompt, system
    budget = max(4000, max_total - overhead)
    return _smart_truncate(prompt, budget), system


def _is_valid_gemini_key(key: str) -> bool:
    """Google AI Studio keys start with AIza. OAuth tokens (AQ., ya29.) are skipped."""
    k = (key or "").strip()
    return bool(k) and k.startswith("AIza")


def _is_valid_groq_key(key: str) -> bool:
    k = (key or "").strip()
    return bool(k) and k.startswith("gsk_")


async def _call_gemini(prompt: str, system: str = "") -> str:
    settings = get_settings()
    if not _is_valid_gemini_key(settings.gemini_api_key):
        raise AIProviderError("Gemini API key not configured or invalid (need AIzaSy... from AI Studio)")

    full = f"{system}\n\n{prompt}" if system else prompt
    model = "gemini-2.0-flash"
    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
        f"?key={settings.gemini_api_key.strip()}"
    )
    payload = {
        "contents": [{"parts": [{"text": full}]}],
        "generationConfig": {"temperature": 0.3, "maxOutputTokens": 8192},
    }
    async with httpx.AsyncClient(timeout=120.0) as client:
        r = await client.post(url, json=payload)
        if r.status_code == 401:
            raise AIProviderError(
                "Gemini authentication failed. Create a new API key at "
                "https://aistudio.google.com/apikey (must start with AIzaSy...)."
            )
        r.raise_for_status()
        data = r.json()
    candidates = data.get("candidates") or []
    if not candidates:
        raise AIProviderError("Gemini returned no candidates")
    parts = candidates[0].get("content", {}).get("parts") or []
    text = "".join(p.get("text", "") for p in parts)
    return text.strip()


async def _call_groq(prompt: str, system: str = "") -> str:
    settings = get_settings()
    if not settings.groq_api_key:
        raise AIProviderError("Groq API key not configured")
    from groq import Groq

    client = Groq(api_key=settings.groq_api_key)
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    try:
        completion = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=messages,
            temperature=0.3,
            max_tokens=4096,
        )
        return completion.choices[0].message.content or ""
    except Exception as e:
        err = str(e)
        if "413" in err or "too large" in err.lower() or "rate_limit" in err.lower():
            short_prompt, short_system = _prepare_for_provider(
                prompt, system, "groq"
            )
            if short_prompt != prompt or short_system != system:
                messages = []
                if short_system:
                    messages.append({"role": "system", "content": short_system})
                messages.append({"role": "user", "content": short_prompt})
                completion = client.chat.completions.create(
                    model="llama-3.3-70b-versatile",
                    messages=messages,
                    temperature=0.3,
                    max_tokens=4096,
                )
                return completion.choices[0].message.content or ""
        raise


async def _call_huggingface(prompt: str, system: str = "") -> str:
    settings = get_settings()
    if not settings.huggingface_api_key:
        raise AIProviderError("Hugging Face API key not configured")
    full = f"{system}\n\n{prompt}" if system else prompt
    async with httpx.AsyncClient(timeout=120.0) as client:
        r = await client.post(
            "https://api-inference.huggingface.co/models/meta-llama/Meta-Llama-3-8B-Instruct",
            headers={"Authorization": f"Bearer {settings.huggingface_api_key}"},
            json={"inputs": full, "parameters": {"max_new_tokens": 2048, "return_full_text": False}},
        )
        r.raise_for_status()
        data = r.json()
        if isinstance(data, list) and data:
            return data[0].get("generated_text", str(data[0]))
        if isinstance(data, dict):
            return data.get("generated_text", json.dumps(data))
        return str(data)


def _active_providers() -> list[tuple[str, Any]]:
    """Groq first (reliable free tier), then Gemini, then Hugging Face."""
    s = get_settings()
    providers: list[tuple[str, Any]] = []
    if _is_valid_groq_key(s.groq_api_key):
        providers.append(("groq", _call_groq))
    if _is_valid_gemini_key(s.gemini_api_key):
        providers.append(("gemini", _call_gemini))
    if s.huggingface_api_key and s.huggingface_api_key.strip():
        providers.append(("huggingface", _call_huggingface))
    return providers


async def _call_demo(prompt: str, system: str = "") -> str:
    """Structured demo response when no API keys are configured."""
    if "Compare these two" in prompt or "Document A:" in prompt:
        return json.dumps({
            "summary": "Demo comparison: Documents show differences in payment terms and liability caps.",
            "risk_comparison": {"doc_a_level": "medium", "doc_b_level": "low", "notes": "Demo mode"},
            "key_differences": [
                {"topic": "Payment Terms", "document_a": "Net 30", "document_b": "Net 45"},
                {"topic": "Liability Cap", "document_a": "Unlimited", "document_b": "Capped at contract value"},
            ],
            "clause_comparison": [{"clause_type": "Termination", "similarity": "medium", "notes": "Different notice periods"}],
        })
    if "Answer the user's question" in prompt or "Question:" in prompt:
        return (
            "Based on the document context (demo mode): This is a sample answer. "
            "Configure GEMINI_API_KEY, GROQ_API_KEY, or HUGGINGFACE_API_KEY for real AI responses."
        )
    return json.dumps({
        "executive_summary": {
            "plain_english": "Demo analysis: This document appears to be a service agreement between two parties with standard commercial terms.",
            "purpose": "Define services, payment, and liability between parties",
            "main_obligations": ["Deliver services per SOW", "Pay fees per schedule", "Maintain confidentiality"],
            "important_dates": [{"label": "Effective Date", "date": "See document"}, {"label": "Term End", "date": "See document"}],
            "parties": [{"name": "Party A", "role": "Service Provider"}, {"name": "Party B", "role": "Client"}],
        },
        "clauses": {
            "termination": [{"title": "Termination for Convenience", "excerpt": "Either party may terminate with 30 days written notice.", "risk": "medium"}],
            "confidentiality": [{"title": "NDA", "excerpt": "Parties shall keep confidential information secret.", "risk": "low"}],
            "payment": [{"title": "Fees", "excerpt": "Client shall pay fees within 30 days of invoice.", "risk": "low"}],
            "liability": [{"title": "Limitation of Liability", "excerpt": "Liability capped except for gross negligence.", "risk": "medium"}],
            "dispute_resolution": [{"title": "Arbitration", "excerpt": "Disputes resolved by binding arbitration.", "risk": "medium"}],
            "governing_law": [{"title": "Governing Law", "excerpt": "Laws of the State specified in the agreement.", "risk": "low"}],
        },
        "risk_analysis": {
            "overall_level": "medium",
            "overall_score": 52,
            "potential_risks": ["Broad indemnification language", "Auto-renewal without cap"],
            "hidden_liabilities": ["Unlimited consequential damages carve-out"],
            "unfavorable_conditions": ["One-sided termination rights"],
            "missing_protections": ["Data breach notification timeline", "Force majeure"],
            "clause_risks": [
                {"clause": "Liability", "score": 65, "level": "medium"},
                {"clause": "Termination", "score": 45, "level": "medium"},
            ],
        },
        "obligations": {
            "party_a": [{"description": "Provide services per SOW", "deadline": "Ongoing"}],
            "party_b": [{"description": "Pay invoices on time", "deadline": "Net 30"}],
            "deliverables": ["Monthly status reports", "Final deliverables per SOW"],
        },
        "legal_insights": {
            "implications": ["Binding agreement upon execution"],
            "considerations": ["Review liability cap and indemnity scope"],
            "compliance_concerns": ["Data processing may require DPA"],
            "recommended_actions": ["Negotiate mutual termination rights", "Add limitation on consequential damages"],
        },
        "recommendations": {
            "suggested_edits": ["Add mutual indemnification cap"],
            "missing_clauses": ["Force majeure", "Data protection addendum"],
            "negotiation_points": ["Payment terms", "Liability cap amount"],
        },
    })


def _has_any_api_key() -> bool:
    return len(_active_providers()) > 0


async def generate_text(prompt: str, system: str = "") -> tuple[str, str]:
    """Try providers in order; return (text, provider_name)."""
    providers = _active_providers()
    if not providers:
        return (await _call_demo(prompt, system), "demo")

    errors: list[str] = []
    for name, fn in providers:
        try:
            p, s = _prepare_for_provider(prompt, system, name)
            text = await fn(p, s)
            if text and text.strip():
                return text.strip(), name
        except Exception as e:
            errors.append(f"{name}: {e}")
    raise AIProviderError("All AI providers failed: " + "; ".join(errors))


def extract_json_from_response(text: str) -> Any:
    """Parse JSON from model output, with fence stripping."""
    cleaned = text.strip()
    fence = re.search(r"```(?:json)?\s*([\s\S]*?)```", cleaned)
    if fence:
        cleaned = fence.group(1).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        start = cleaned.find("{")
        end = cleaned.rfind("}") + 1
        if start >= 0 and end > start:
            return json.loads(cleaned[start:end])
        raise


ANALYSIS_SYSTEM = """You are LegalAI, an expert legal document analyst.
Respond ONLY with valid JSON matching the requested schema.
Be precise, cite document sections when possible, and flag uncertainties.
Never invent parties or dates not present in the document."""

ANALYSIS_PROMPT_TEMPLATE = """Analyze this legal document and return JSON with this exact structure:
{{
  "executive_summary": {{
    "plain_english": "string",
    "purpose": "string",
    "main_obligations": ["string"],
    "important_dates": [{{"label": "string", "date": "string"}}],
    "parties": [{{"name": "string", "role": "string"}}]
  }},
  "clauses": {{
    "termination": [{{"title": "string", "excerpt": "string", "risk": "low|medium|high"}}],
    "confidentiality": [{{"title": "string", "excerpt": "string", "risk": "low|medium|high"}}],
    "payment": [{{"title": "string", "excerpt": "string", "risk": "low|medium|high"}}],
    "liability": [{{"title": "string", "excerpt": "string", "risk": "low|medium|high"}}],
    "dispute_resolution": [{{"title": "string", "excerpt": "string", "risk": "low|medium|high"}}],
    "governing_law": [{{"title": "string", "excerpt": "string", "risk": "low|medium|high"}}]
  }},
  "risk_analysis": {{
    "overall_level": "low|medium|high",
    "overall_score": 0-100,
    "potential_risks": ["string"],
    "hidden_liabilities": ["string"],
    "unfavorable_conditions": ["string"],
    "missing_protections": ["string"],
    "clause_risks": [{{"clause": "string", "score": 0-100, "level": "low|medium|high"}}]
  }},
  "obligations": {{
    "party_a": [{{"description": "string", "deadline": "string|null"}}],
    "party_b": [{{"description": "string", "deadline": "string|null"}}],
    "deliverables": ["string"]
  }},
  "legal_insights": {{
    "implications": ["string"],
    "considerations": ["string"],
    "compliance_concerns": ["string"],
    "recommended_actions": ["string"]
  }},
  "recommendations": {{
    "suggested_edits": ["string"],
    "missing_clauses": ["string"],
    "negotiation_points": ["string"]
  }}
}}

Language for summaries: {language}

Document text (truncated if needed):
---
{document_text}
---"""


def _analysis_doc_limit() -> int:
    """Conservative document body limit based on active AI provider."""
    providers = _active_providers()
    if not providers:
        return 50_000
    primary = providers[0][0]
    if primary == "groq":
        return 12_000
    if primary == "gemini":
        return 100_000
    return 50_000


async def analyze_document(text: str, language: str = "en") -> dict:
    max_chars = _analysis_doc_limit()
    truncated = len(text) > max_chars
    doc = text[:max_chars]
    if truncated:
        doc += "\n\n[Document truncated for analysis]"

    prompt = ANALYSIS_PROMPT_TEMPLATE.format(document_text=doc, language=language)
    raw, provider = await generate_text(prompt, ANALYSIS_SYSTEM)
    try:
        result = extract_json_from_response(raw)
        result["_meta"] = {
            "provider": provider,
            "document_truncated": truncated or len(prompt) > GROQ_MAX_INPUT_CHARS,
        }
        return result
    except Exception:
        return {
            "executive_summary": {
                "plain_english": raw[:2000],
                "purpose": "See full analysis text",
                "main_obligations": [],
                "important_dates": [],
                "parties": [],
            },
            "clauses": {},
            "risk_analysis": {"overall_level": "medium", "overall_score": 50},
            "obligations": {"party_a": [], "party_b": [], "deliverables": []},
            "legal_insights": {"implications": [raw[:1000]]},
            "recommendations": {},
            "_meta": {"provider": provider, "parse_error": True},
        }


COMPARE_PROMPT = """Compare these two legal documents. Return JSON:
{{
  "summary": "string",
  "risk_comparison": {{"doc_a_level": "low|medium|high", "doc_b_level": "low|medium|high", "notes": "string"}},
  "key_differences": [{{"topic": "string", "document_a": "string", "document_b": "string"}}],
  "clause_comparison": [{{"clause_type": "string", "similarity": "high|medium|low", "notes": "string"}}]
}}

Document A:
---
{doc_a}
---

Document B:
---
{doc_b}
---"""


async def compare_documents(text_a: str, text_b: str) -> dict:
    per_doc = 6_000 if (_active_providers() and _active_providers()[0][0] == "groq") else 25_000
    prompt = COMPARE_PROMPT.format(
        doc_a=_smart_truncate(text_a, per_doc),
        doc_b=_smart_truncate(text_b, per_doc),
    )
    raw, provider = await generate_text(prompt, ANALYSIS_SYSTEM)
    try:
        result = extract_json_from_response(raw)
        result["_meta"] = {"provider": provider}
        return result
    except Exception:
        return {"summary": raw, "_meta": {"provider": provider}}
