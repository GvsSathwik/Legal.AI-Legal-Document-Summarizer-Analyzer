import hashlib
import math
import re
from typing import Optional

from app.services.ai_providers import ANALYSIS_SYSTEM, generate_text


def chunk_text(text: str, chunk_size: int = 1000, overlap: int = 200) -> list[dict]:
    paragraphs = re.split(r"\n\s*\n", text)
    chunks: list[str] = []
    current = ""

    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
        if len(current) + len(para) + 2 <= chunk_size:
            current = f"{current}\n\n{para}".strip() if current else para
        else:
            if current:
                chunks.append(current)
            while len(para) > chunk_size:
                chunks.append(para[:chunk_size])
                para = para[chunk_size - overlap :]
            current = para
    if current:
        chunks.append(current)

    if not chunks and text:
        for i in range(0, len(text), chunk_size - overlap):
            chunks.append(text[i : i + chunk_size])

    return [
        {
            "id": hashlib.sha256(f"{i}:{c[:50]}".encode()).hexdigest()[:16],
            "index": i,
            "content": c,
            "embedding": _simple_embedding(c),
        }
        for i, c in enumerate(chunks)
    ]


def _simple_embedding(text: str, dim: int = 128) -> list[float]:
    """Lightweight bag-of-words style embedding (no external API)."""
    vec = [0.0] * dim
    tokens = re.findall(r"[a-z0-9]+", text.lower())
    for tok in tokens:
        h = int(hashlib.md5(tok.encode()).hexdigest(), 16)
        vec[h % dim] += 1.0
    norm = math.sqrt(sum(x * x for x in vec)) or 1.0
    return [x / norm for x in vec]


def _cosine(a: list[float], b: list[float]) -> float:
    return sum(x * y for x, y in zip(a, b))


def search_chunks(chunks: list[dict], query: str, top_k: int = 5) -> list[dict]:
    q_emb = _simple_embedding(query)
    scored = [( _cosine(q_emb, c["embedding"]), c) for c in chunks]
    scored.sort(key=lambda x: x[0], reverse=True)
    return [c for _, c in scored[:top_k]]


CHAT_PROMPT = """Answer the user's question about the legal document using ONLY the provided context.
If the answer is not in the context, say so clearly.
Be concise and cite relevant sections.

Context:
{context}

Question: {question}

Language: {language}"""


async def chat_with_document(
    chunks: list[dict],
    question: str,
    language: str = "en",
) -> dict:
    relevant = search_chunks(chunks, question, top_k=5)
    context = "\n\n---\n\n".join(
        f"[Chunk {c['index']+1}]\n{c['content']}" for c in relevant
    )
    prompt = CHAT_PROMPT.format(context=context, question=question, language=language)
    answer, provider = await generate_text(prompt, ANALYSIS_SYSTEM)
    return {
        "answer": answer,
        "sources": [{"index": c["index"], "preview": c["content"][:200]} for c in relevant],
        "provider": provider,
    }
