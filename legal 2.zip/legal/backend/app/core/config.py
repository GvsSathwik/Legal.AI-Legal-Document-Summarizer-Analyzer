from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "LegalAI Backend"
    debug: bool = False
    cors_origins: str = "http://localhost:3000"

    # Supabase
    supabase_url: str = ""
    supabase_service_key: str = ""
    supabase_jwt_secret: str = ""

    # AI Providers (free tier)
    gemini_api_key: str = ""
    groq_api_key: str = ""
    huggingface_api_key: str = ""

    # Rate limiting
    rate_limit_per_minute: int = 30

    # Storage
    upload_max_mb: int = 25
    storage_bucket: str = "documents"

    class Config:
        env_file = ".env"
        extra = "ignore"


def get_settings() -> Settings:
    """Reload settings each call so .env changes apply after restart."""
    return Settings()
