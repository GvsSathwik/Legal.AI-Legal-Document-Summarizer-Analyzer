from fastapi import APIRouter, File, Form, HTTPException, UploadFile

from app.core.config import get_settings
from app.services.ai_providers import analyze_document, compare_documents
from app.services.document_parser import parse_document
from app.services.rag_service import chat_with_document, chunk_text

router = APIRouter(prefix="/documents", tags=["documents"])


@router.post("/parse")
async def parse_upload(
    file: UploadFile = File(...),
    force_ocr: bool = Form(False),
):
    settings = get_settings()
    data = await file.read()
    max_bytes = settings.upload_max_mb * 1024 * 1024
    if len(data) > max_bytes:
        raise HTTPException(413, f"File exceeds {settings.upload_max_mb}MB limit")

    if not file.filename:
        raise HTTPException(400, "Filename required")

    try:
        result = parse_document(file.filename, data, force_ocr=force_ocr)
        chunks = chunk_text(result["text"])
        result["chunks"] = [{"id": c["id"], "index": c["index"], "content": c["content"]} for c in chunks]
        result["chunk_count"] = len(chunks)
        return result
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/analyze")
async def analyze(
    text: str = Form(...),
    language: str = Form("en"),
):
    if not text.strip():
        raise HTTPException(400, "Document text is required")
    try:
        analysis = await analyze_document(text, language=language)
        return analysis
    except Exception as e:
        raise HTTPException(502, f"Analysis failed: {e}")


@router.post("/chat")
async def chat(
    text: str = Form(...),
    question: str = Form(...),
    language: str = Form("en"),
):
    if not question.strip():
        raise HTTPException(400, "Question is required")
    chunks = chunk_text(text)
    try:
        return await chat_with_document(chunks, question, language=language)
    except Exception as e:
        raise HTTPException(502, f"Chat failed: {e}")


@router.post("/compare")
async def compare(
    text_a: str = Form(...),
    text_b: str = Form(...),
):
    try:
        return await compare_documents(text_a, text_b)
    except Exception as e:
        raise HTTPException(502, f"Compare failed: {e}")
