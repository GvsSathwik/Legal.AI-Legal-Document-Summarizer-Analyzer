# Legal Project

This repository contains the frontend and backend source code for the legal application.

## Structure

- `backend/app/`: Python backend source code
- `frontend/src/`: Frontend source code

## Notes

This is a cleaned repository containing only source files and GitHub metadata. Restore package manifests and dependency files if you need to run the app locally.
